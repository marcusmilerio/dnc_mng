﻿$dir   = Split-Path -Parent $MyInvocation.MyCommand.Path
$zip   = "$dir\CND_Manager.zip"
$dest  = $dir

Write-Host "Juntando partes..."
$parts = Get-ChildItem $dir -Filter "parte*.bin" | Sort-Object Name
$out   = [IO.File]::OpenWrite($zip)
foreach ($p in $parts) {
    $b = [IO.File]::ReadAllBytes($p.FullName)
    $out.Write($b, 0, $b.Length)
    Write-Host "  Lido: $($p.Name)"
}
$out.Close()

Write-Host "Extraindo..."
Add-Type -Assembly "System.IO.Compression.FileSystem"
[IO.Compression.ZipFile]::ExtractToDirectory($zip, $dest)
Remove-Item $zip

Write-Host ""
Write-Host "Pronto! Abra a pasta CND_Manager e execute instalar.bat"

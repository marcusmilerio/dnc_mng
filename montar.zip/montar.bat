@echo off
echo Montando CND Manager - aguarde...
powershell -NoProfile -ExecutionPolicy Bypass -File "%~dp0montar.ps1"
pause
